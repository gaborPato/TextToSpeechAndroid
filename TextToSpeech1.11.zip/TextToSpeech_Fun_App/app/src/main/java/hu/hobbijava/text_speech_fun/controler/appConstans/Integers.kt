package hu.hobbijava.text_speech_fun.controler.appConstans

import android.net.NetworkCapabilities

object Integers {

const val wifiConn= NetworkCapabilities.TRANSPORT_WIFI
const val cellPhoneConn= NetworkCapabilities.TRANSPORT_CELLULAR




}