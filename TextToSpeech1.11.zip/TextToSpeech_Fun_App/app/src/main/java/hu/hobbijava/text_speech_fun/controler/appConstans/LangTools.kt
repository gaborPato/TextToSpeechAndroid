package hu.hobbijava.text_speech_fun.controler.appConstans

import java.util.*

object LangTools {

    fun setLangForTranslate(locale: Locale): String {

        when(locale.language){

             "zh" ->  return "zh-CN"
            "nb" -> return "no"
            else -> return locale.language
        }
    }
}