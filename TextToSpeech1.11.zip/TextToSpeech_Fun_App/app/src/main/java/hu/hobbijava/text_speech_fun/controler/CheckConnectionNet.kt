package hu.hobbijava.text_speech_fun.controler

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.NetworkInfo
import android.os.Build
import androidx.core.content.getSystemService

object CheckConnectionNet {
    @JvmStatic
    fun checkInternet(context: Context):Boolean{


        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager




        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val activeNetwork = connectivityManager.activeNetwork
            if (activeNetwork == null) {
                return false
            }
            val networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork)

            return ( networkCapabilities != null && (networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                    || networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)))


        } else {
            val wifiNetInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI)
            val cellNetInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE)

            if (wifiNetInfo == null || cellNetInfo == null){
                return false

            }
            return   (wifiNetInfo.state == NetworkInfo.State.CONNECTED
                    || cellNetInfo.state == NetworkInfo.State.CONNECTED)





        }
    }
}