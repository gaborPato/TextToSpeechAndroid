package hu.hobbijava.text_speech_fun

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import hu.hobbijava.text_speech_fun.controler.CheckConnectionNet
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*
import android.content.ActivityNotFoundException
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.util.Log
import android.view.WindowManager
import hu.hobbijava.text_speech_fun.controler.appConstans.LangTools
import java.lang.Exception
import java.lang.StringBuilder
import java.net.URLEncoder


class MainActivity() : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var textToSpeech: TextToSpeech
    private lateinit var locale: Locale


    companion object {

        private val TTS_ENGINE_REQUEST = 1002
        private val  REQ_CODE_SPEECH_INPUT = 100
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        this.window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)
        locale= Locale.getDefault()
        system_lang_speech_btn.text= locale.displayLanguage
        if (CheckConnectionNet.checkInternet(applicationContext)){
            showToast("connection ok")

        }else{
            showToast("no connection!!")
            NetAlertBuilder.getAlertDialog(this).show()
        }
    }

    override fun onInit(status: Int) {

        if (status == TextToSpeech.SUCCESS) {
            val languageStatus = textToSpeech.setLanguage(locale)
            if (languageStatus == TextToSpeech.LANG_MISSING_DATA || languageStatus == TextToSpeech.LANG_NOT_SUPPORTED) {

                showToast("Lang is not supported")
            } else {
                val data = speechEditTextField.text.toString()
                val speakStatus = textToSpeech.speak(data, TextToSpeech.QUEUE_FLUSH, null, "speak")
                if (speakStatus == TextToSpeech.ERROR) {
                    showToast("Error while speak")
                }
            }
        } else {
            showToast("text to speech engine failed")
        }


    }
    fun translateClick(view: View){

        if (!CheckConnectionNet.checkInternet(applicationContext)){
            showToast("No connection")
            NetAlertBuilder.getAlertDialog(this).show()
            return
        }

        val userText= speechEditTextField.text.toString()
        if (userText.length<1) {return}
        val lang:String= LangTools.setLangForTranslate(locale)


        var encode=""
        try {
            encode= URLEncoder.encode(userText,"UTF-8")

        }catch (ex:Exception){



            showToast(ex.message)
            Log.e("urlError",ex.message)
            return
        }

        val url: String = "https://translate.google.com/#view=home&op=translate&sl=auto&tl=${lang}&text=${encode}"

        val intent= Intent()

        if( Build.VERSION.SDK_INT>22){
            intent.setClass(this,WebViewActivity::class.java)
            intent.putExtra("pass_url",url)
        }else{
            intent.action= Intent.ACTION_VIEW
            intent.data=Uri.parse(url)

        }



        startActivity(intent)

    }

    fun speechClick(view: View) {


        when (view.id) {
            system_lang_speech_btn.id -> {
                locale = Locale.getDefault()
                root_Frame_layout.setBackgroundColor(Color.WHITE)
            }
            speech_english.id -> {
                locale = Locale.US
               // root_Frame_layout.setBackgroundResource(R.drawable.usa)
                activity_background_image.setImageResource(R.drawable.usa)
            }
            speech_italy.id -> {
                locale = Locale.ITALY
                activity_background_image.setImageResource(R.drawable.italy_flag)
            }
            speech_esp.id -> {
                locale= Locale("es","ES")
                activity_background_image.setImageResource(R.drawable.espanol_flag)
            }
            speech_chinese.id ->{
                locale = Locale.SIMPLIFIED_CHINESE
                activity_background_image.setImageResource(R.drawable.china)
            }
            speech_franc.id -> {
                locale = Locale.FRENCH
                activity_background_image.setImageResource(R.drawable.france)
            }
            speech_japan.id -> {
                locale = Locale.JAPAN
                activity_background_image.setImageResource(R.drawable.japan)
            }
            speech_germany.id -> {
                locale = Locale.GERMAN
                activity_background_image.setImageResource(R.drawable.germany)
            }
            speech_norwegian.id -> {
                locale = Locale("nb","NO")
                activity_background_image.setImageResource(R.drawable.norwegian)
            }
            speaker_icon.id -> {
                if (speechEditTextField.text.toString().length<1){
                    return
                }
                val checkIntent: Intent = Intent()
                checkIntent.action = TextToSpeech.Engine.ACTION_CHECK_TTS_DATA
                startActivityForResult(checkIntent, TTS_ENGINE_REQUEST)
            }


        }
        showToast(locale.displayLanguage)

    }

    @SuppressLint("MissingSuperCall")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == TTS_ENGINE_REQUEST && resultCode == TextToSpeech.Engine.CHECK_VOICE_DATA_PASS) {

            textToSpeech = TextToSpeech(this, this)


        } else {
             val installIntent = Intent()
            installIntent.action = TextToSpeech.Engine.ACTION_CHECK_TTS_DATA
            startActivity(installIntent)
        }
        if (requestCode == REQ_CODE_SPEECH_INPUT){
            if (resultCode == Activity.RESULT_OK && data != null){

                val result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
              if(result != null){
                  val cursorPosition= speechEditTextField.selectionStart
                  val originText= speechEditTextField.text.toString()

                  val text0= originText.subSequence(0,cursorPosition)
                  val text1= originText.subSequence(cursorPosition,originText.length)
                  var makeText=StringBuilder(text0)
                  makeText.append(result[0])
                  makeText.append(text1)


                  speechEditTextField.setText(makeText)
                  speechEditTextField.setSelection(speechEditTextField.text.toString().length)
              }else return



            }

        }

    }

    fun clearTextClick(view: View) {

       speechEditTextField.setText("")
    }

   private object NetAlertBuilder{

       fun getAlertDialog(context: Context):AlertDialog.Builder{

           val alBuilder= AlertDialog.Builder(context)

           return AlertDialog.Builder(context)
               .setTitle("No network !!")
               .setMessage("Some languages may require an online connection.")
               .setIcon(R.drawable.no_network)


       }

    }

    fun input_speech_click(view: View) {

        val intent= Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,locale)
        try {
            startActivityForResult(intent, REQ_CODE_SPEECH_INPUT)
        } catch (a: ActivityNotFoundException) {

        }

    }

    private fun showToast(message:String?)= Toast.makeText(this,message,Toast.LENGTH_SHORT).show()

}



